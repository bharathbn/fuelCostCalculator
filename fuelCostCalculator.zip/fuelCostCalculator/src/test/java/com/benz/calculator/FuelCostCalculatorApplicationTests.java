package com.benz.calculator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FuelCostCalculatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
